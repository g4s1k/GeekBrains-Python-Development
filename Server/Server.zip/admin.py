USERNAME = 'Admin'
LOGIN = 'admin'
PASSWORD = 'password'